docker build -t log8415-tp1 . && 
docker run log8415-tp1
